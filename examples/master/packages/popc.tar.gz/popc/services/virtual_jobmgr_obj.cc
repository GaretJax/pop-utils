#include "virtual_jobmgr.ph"

@pack(VirtualJobMgr, JobMgr)

