#include "virtual_secure_jobmgr.ph"

@pack(VirtSecureJobMgr, VirtualJobMgr, JobMgr)
