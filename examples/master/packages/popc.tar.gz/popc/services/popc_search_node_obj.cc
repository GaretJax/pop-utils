/*
	File added by clementval.
	Allow the creation of a executable POPCSearchNode object as a service
*/

#include "popc_search_node.ph"

@pack(POPCSearchNode)
