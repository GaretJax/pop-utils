#include "virtual_secure_popc_search_node.ph"

@pack(VirtSecurePOPCSearchNode, VirtualPOPCSearchNode, POPCSearchNode)
