//-------------------------------------------
#ifndef _X_H
#define _X_H

class X
{
public:
	X();
	~X();
	int GetIdent();
	void SetIdent(int i);


private:
	int ident;
};

#endif
