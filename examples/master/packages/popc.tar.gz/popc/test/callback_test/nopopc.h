#define parclass class
#define seq
#define async
#define sync
#define conc
#define mutex
#define POPString char*
#define @{od ;//
#define [in]
#define  @pack( //