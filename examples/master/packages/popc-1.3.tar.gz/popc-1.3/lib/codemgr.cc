/*
AUTHORS: Tuan Anh Nguyen

DESCRIPTION: code manager service object
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "codemgr.ph"

CodeMgr::CodeMgr(const paroc_string &challenge): paroc_service_base(challenge)
{
}

CodeMgr::~CodeMgr()
{
	DEBUG("Now destroy CodeMgr\n");

}

void CodeMgr::RegisterCode(const paroc_string &objname, const paroc_string &platform, const paroc_string &codefile)
{
	int n=info.GetSize();
	int i;
	codedb *element;
	for (i=0;i<n;i++) if (paroc_utils::isEqual(objname,info[i].objname)) break;

	if (i<n) element=&(info[i]);
	else
	{
		info.SetSize(n+1);
		element=&(info[n]);
		strcpy(element->objname,objname);
	}

	n=element->platform.GetSize();
	for (i=0;i<n;i++) if (paroc_utils::isEqual(platform,element->platform[i].platform)) break;

	if (i<n)
	{
		DEBUG("Changing (%s, %s) -> %s\n",element->objname,element->platform[i].platform,(const char *)codefile);
		strcpy(element->platform[i].codefile,codefile);
	}
	else
	{
		element->platform.SetSize(n+1);
		strcpy(element->platform[n].codefile,codefile);
		strcpy(element->platform[n].platform,platform);
	}
}

int CodeMgr::QueryCode(const paroc_string &objname, const paroc_string &platform, paroc_string &codefile)
{
	codefile=NULL;
	int n=info.GetSize();
	int i;
	codedb *element;
	for (i=0;i<n;i++) if (paroc_utils::isEqual(objname,info[i].objname)) break;

	if (i>=n) return 0;

	element=&(info[i]);
	n=element->platform.GetSize();
	for (i=0;i<n;i++) if (paroc_utils::MatchWildcard(platform,element->platform[i].platform)) break;

	if (i>=n) return 0;
	codefile=element->platform[i].codefile;
	return 1;
}

int CodeMgr::GetPlatform(const paroc_string &objname, paroc_string &platform)
{
	int count=0;
	platform=NULL;
	int n=info.GetSize();
	int i;
	for (i=0;i<n;i++) if (paroc_utils::isEqual(objname,info[i].objname)) break;
	if (i>=n) return 0;
	codedb &element=info[i];
	n=element.platform.GetSize();
	for (i=0;i<n;i++)
	{
		platform+=element.platform[i].platform;
		if (i<n-1) platform+=" ";
	}
	return n;
}
